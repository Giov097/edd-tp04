# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['tp_04',
 'tp_04.ejercicio_01',
 'tp_04.ejercicio_03',
 'tp_04.ejercicio_05',
 'tp_04.ejercicio_07']

package_data = \
{'': ['*']}

install_requires = \
['python-ed-fcad-uner @ '
 'git+https://github.com/nachonovello1984/python_ed_fcad_uner.git@main']

setup_kwargs = {
    'name': 'tp-04',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Geronimo Giovenale',
    'author_email': 'geronimo.giovenale@devify.it',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
