# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['tp_04', 'tp_04.ejercicio_01']

package_data = \
{'': ['*']}

install_requires = \
['data_structures>=0.1.6,<0.2.0',
 'python_ed_fcad_uner @ '
 'git+https://github.com/nachonovello1984/python_ed_fcad_uner.git']

setup_kwargs = {
    'name': 'tp-04',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Geronimo Giovenale',
    'author_email': 'geronimo.giovenale@devify.it',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
