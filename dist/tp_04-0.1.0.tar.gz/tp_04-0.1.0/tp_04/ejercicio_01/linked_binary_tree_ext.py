from linked_binary_tree_ext_abstract import LinkedBinaryTreeExtAbstract


class LinkedBinaryTreeExt(LinkedBinaryTreeExtAbstract):
    pass
